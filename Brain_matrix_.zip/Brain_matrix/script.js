const taskInput = document.getElementById('taskInput');
const addTaskButton = document.getElementById('addTaskButton');
const taskList = document.getElementById('taskList');

function addTask() {
  const taskText = taskInput.value.trim();

    if (taskText === '') {
    alert('Please enter a task!');
    taskInput.focus();
    return;
  }

  const existingTasks = Array.from(taskList.querySelectorAll('span')).map(
    (span) => span.textContent.trim()
  );
  if (existingTasks.includes(taskText)) {
    alert('Task already exists!');
    taskInput.focus();
    return;
  }

  // Create a new task item
  const taskItem = document.createElement('li');

  // Task text
  const taskSpan = document.createElement('span');
  taskSpan.textContent = taskText;
  taskItem.appendChild(taskSpan);

  // Edit button
  const editButton = document.createElement('button');
  editButton.textContent = '✏️';
  editButton.className = 'edit-button';
  editButton.onclick = () => editTask(taskSpan, taskItem);
  taskItem.appendChild(editButton);

  // Delete button
  const deleteButton = document.createElement('button');
  deleteButton.textContent = '🗑️';
  deleteButton.className = 'delete-button';
  deleteButton.onclick = () => taskItem.remove();
  taskItem.appendChild(deleteButton);

  
  taskSpan.onclick = () => {
    taskItem.classList.toggle('completed');
  };

  taskList.appendChild(taskItem);

    taskInput.value = '';
  taskInput.focus();
}

function editTask(taskSpan, taskItem) {
  
  const existingInput = taskList.querySelector('input[type="text"]');
  if (existingInput) {
    alert('Finish editing the current task first!');
    existingInput.focus();
    return;
  }

  const currentText = taskSpan.textContent;

  
  const editInput = document.createElement('input');
  editInput.type = 'text';
  editInput.value = currentText;
  editInput.style.flexGrow = '1';

  taskSpan.replaceWith(editInput);
  editInput.focus();

    editInput.onblur = () => saveEdit(editInput, taskSpan, currentText);
  editInput.onkeypress = (e) => {
    if (e.key === 'Enter') saveEdit(editInput, taskSpan, currentText);
  };
}

function saveEdit(editInput, taskSpan, originalText) {
  const updatedText = editInput.value.trim();

  
  if (updatedText === '') {
    alert("Please enter a task!");
    editInput.replaceWith(taskSpan);
    taskSpan.textContent = originalText; 
    return;
  }

  
  taskSpan.textContent = updatedText;
  editInput.replaceWith(taskSpan);
}

// Event listeners
addTaskButton.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addTask();
  }
});
