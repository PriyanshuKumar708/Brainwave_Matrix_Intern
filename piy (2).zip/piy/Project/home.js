let products=[]
function fetchData(){
    fetch("https://dummyjson.com/products").then((res)=>{
       return res.json();
    }).then((val)=>{
        console.log(val);
        // console.log(val.products)
        // products=res.products;
        // console.log(products)
        products=val.products;
        localStorage.setItem("data",JSON.stringify(products))
        fetchProduct(products);
    })
}
function fetchProduct(products){
    let output=""
    products.map((val)=>{
       output+=`<main id="box"><div id="prductImage">
       <img src="${val.images[0]}"></div>
       <h3>Name:${val.title}</h3>
       <h3>Price:&#8377 ${val.price}</h3>
       <h3>Rating:${val.rating}</h3>
       <h3><button id="button" onclick="viewMore(${val.id})">View More</button></h3>
       
       
       </main>`
    })
    document.getElementById("root").innerHTML=output;
}

// fetchProduct();

// fetchData();


function searchTerm(event){
    let searchitem=event.target.value.toLowerCase();
    let filterProd=products.filter((val)=>
        val.title.toLowerCase().includes(searchitem)||
        val.category.toLowerCase().includes(searchitem)
    );
    fetchProduct(filterProd)
}
document.getElementById("SearchProduct").addEventListener("input",searchTerm);


function viewMore(ProductId){
    localStorage.setItem("selectedProductId",ProductId)
    window.location.href="./viewMore.html"
}
fetchData();