document.addEventListener("DOMContentLoaded",displayCart());

function displayCart(){
    let cardContent=document.getElementById("CartContent");
    let totalPrice=document.getElementById("totalPrice")
    let cart=JSON.parse(localStorage.getItem("cart"))||[];
    console.log(cart);
    cardContent.innerHTML=" ";
    let total=0;
    if(cart.length===0){
        cardContent.innerHTML=`<p class="empty-message"> your cart is empty.Start shooping </p>`
        totalPrice.innerHTML=" ";
        return;
    }
    cart.map((product,index)=>{
        total+=product.price;
        let productDiv=document.createElement("div");
        productDiv.classList.add("product-info");
        productDiv.innerHTML=`<img src="${product.images[0]}" alt="${product.title}"/>
       <h3>Price:&#8377 ${product.price}</h3>
        <h3>Brand:${product.brand}</h3>
        <h3>ReturnPolicy:${product.returnPolicy}</h3>
        <h3>AvailabilityStatus:${product.availabilityStatus
                }</h3>
        
        <button onclick="removeFromCart(${index})">Remove</button>
        `
        cardContent.appendChild(productDiv);
    });
    totalPrice.innerHTML=`<h1>Total Price:&#8377 ${total}</h1>`

}
function removeFromCart(index){
    let cart=JSON.parse(localStorage.getItem("cart"))||[];
    cart.splice(index,1);
    localStorage.setItem("cart",JSON.stringify(cart));
    displayCart();
}