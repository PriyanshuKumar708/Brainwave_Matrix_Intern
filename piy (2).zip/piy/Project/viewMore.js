document.addEventListener("DOMContentLoaded",()=>{
    let products=JSON.parse(localStorage.getItem("data"))
    // console.log(products)
    let productDetails=document.getElementById("productDetails");
    let selectedProductId=localStorage.getItem("selectedProductId");
    if(products && selectedProductId ){
        let selectedProduct=products.find(
            (product)=>product.id==selectedProductId
            )
            if(selectedProduct){
                productDetails.innerHTML=`<div class="image"><img src="${selectedProduct.images[0]}"/></div> 
                <div class="content"><div class="itemInfo"><h3> Name:${selectedProduct.title}</h3>
                <h3>Category:${selectedProduct.category}</h3>
                <h3>Brand:${selectedProduct.brand}</h3>
                <h3>Discount:${selectedProduct.discountPercentage}</h3>
                <h3>Price:&#8377 ${selectedProduct.price}</h3>
                <h3>ReturnPolicy:${selectedProduct.returnPolicy}</h3>
                <h3>AvailabilityStatus:${selectedProduct.availabilityStatus
                }</h3>
                <h3>Waranty:${selectedProduct.warrantyInformation
                }</h3>
                <p><b>Description:</b>${selectedProduct.description}</p>
                <h3><button id="addToCart">Add to cart</button></h3>
                <h3><button id="backTohome">Back to home</button></h3>
                </div>
                </div>`;
                let output="";
                output+=` <h1>Customer Reviews</h1><main class="reviews">`
                selectedProduct.reviews.map((val)=>{
                   output+=`<div class="reviewsContent">
                       <h3>ReviewerName:${val.reviewerName}</h3>
                       <h3>Comment:${val.comment}</h3>
                       <h3>Rating:${"💗".repeat(val.rating)}${"🖤".repeat(5-val.rating)}</h3>
                       <h3>Date:${val.date}</h3>
                       
                       <h3>ReviewerEmail:${val.reviewerEmail}</h3>
                      
                   </div>` 
                })
                output+=`</main>`
                document.getElementById("reviews").innerHTML=output;

                document.getElementById("addToCart").addEventListener("click",()=>{
                    addToCart(selectedProduct);
                });
                document.getElementById("backTohome").addEventListener("click",()=>{
                    window.location.href="./home.html"
                })
               
            }
            else{
                productDetails.innerHTML="<p>product not found</p>"
            }
    }
    else{
        productDetails.innerHTML="<p>No product selected</p>"
    }
});
function addToCart(product){
    let cart=JSON.parse(localStorage.getItem("cart"))|| [];
    cart.push(product);
    localStorage.setItem("cart",JSON.stringify(cart));
    alert("prdouct added successfully to cart ")
}
