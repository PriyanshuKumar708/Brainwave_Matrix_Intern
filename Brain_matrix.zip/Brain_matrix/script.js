// Select elements
const taskInput = document.getElementById('taskInput');
const addTaskButton = document.getElementById('addTaskButton');
const taskList = document.getElementById('taskList');


// Add task function
function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText === '') {
    alert('Please enter a task!');
    return;
  }

  // Create task item
  const taskItem = document.createElement('li');

  // Task text
  const taskSpan = document.createElement('span');
  taskSpan.textContent = taskText;
  taskItem.appendChild(taskSpan);

 

  // Edit button
  const editButton = document.createElement('button');
  editButton.textContent = '✏️';
  editButton.className = 'edit-button';
  editButton.onclick = () => editTask(taskSpan);
  taskItem.appendChild(editButton);

  // Delete button
  const deleteButton = document.createElement('button');
  deleteButton.textContent = '🗑️';
  deleteButton.className = 'delete-button';
  deleteButton.onclick = () => taskItem.remove();
  taskItem.appendChild(deleteButton);

  // Mark as completed on click
  taskSpan.onclick = () => {
    taskItem.classList.toggle('completed');
  };

  // Add task to list
  taskList.appendChild(taskItem);

  // Clear input
  taskInput.value = '';
}

// Function to edit a task
function editTask(taskSpan) {
  // Store current text
  const currentText = taskSpan.textContent;

  // Replace task text with an input field
  const editInput = document.createElement('input');
  editInput.type = 'text';
  editInput.value = currentText;
  editInput.style.width = '70%';

  // Replace the span with the input field
  taskSpan.replaceWith(editInput);

  // Focus on the input field
  editInput.focus();

  // Save the edited task on blur or Enter key press
  editInput.onblur = () => saveEdit(editInput, taskSpan);
  editInput.onkeypress = (e) => {
    if (e.key === 'Enter') saveEdit(editInput, taskSpan);
  };
}

// Save the edited task
function saveEdit(editInput, taskSpan) {
  const updatedText = editInput.value.trim();
  if (updatedText === '') {
    alert('Task cannot be empty!');
    return;
  }

  // Update the span with the new text
  taskSpan.textContent = updatedText;

  // Reattach the span to the task item
  editInput.replaceWith(taskSpan);
}

// Event listener for adding a task
addTaskButton.addEventListener('click', addTask);

// Add task on pressing "Enter"
taskInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addTask();
  }
});
